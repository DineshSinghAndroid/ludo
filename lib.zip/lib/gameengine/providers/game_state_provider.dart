import 'package:flutter/material.dart';

class GameStateProvider with ChangeNotifier{
  
}