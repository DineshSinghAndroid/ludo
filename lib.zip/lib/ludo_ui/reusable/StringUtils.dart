class StringUtils {
   static String signIn = "Sign in with Google";
   static String lorem = "Lorem ipsum dolor sit amet,\nconsectetur adipiscing elit.";
   static String signup = "Signup";
   static String selectCountry = 'Select a country';
   static String selectProfile = "Select Profile Picture";
   static String continueText = "Continue";
}